SendKeys is a Python module for Windows (R) 
which can be used to send one or more keystrokes or keystroke 
combinations to the active window.

